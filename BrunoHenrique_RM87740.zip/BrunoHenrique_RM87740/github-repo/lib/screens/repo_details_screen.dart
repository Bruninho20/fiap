import 'package:flutter/material.dart';
import 'package:githubrepo/components/all.dart';
import 'package:githubrepo/constants/typography.dart';
import 'package:githubrepo/mocks/repositories_mock.dart';
import 'package:githubrepo/models/repository.dart';

class RepoDetailsScreen extends StatefulWidget {
  const RepoDetailsScreen({super.key});

  @override
  State<RepoDetailsScreen> createState() => _RepoDetailsScreenState();
}

class _RepoDetailsScreenState extends State<RepoDetailsScreen> {
  @override
  Widget build(BuildContext context) {
    List<Repository> repo = kRepositoriesMock;
    return Scaffold(
      appBar: CustomAppBar(
        text: 'Detalhes',
      ),
      body: Container(
          child: Center(
        child: Column(
          children: [
            CustomAvatar(
              avatarUrl: repo[0].owner?.avatar,
              radius: 50,
            ),
            const SizedBox(
              height: 10,
            ),
            const CustomText(text: "Repositório", style: TypographyType.title),
            CustomText(text: '${repo[0].name}', style: TypographyType.body),
            const SizedBox(
              height: 10,
            ),
            const CustomText(
                text: "Nome do repositório", style: TypographyType.title),
            CustomText(
                text: '${repo[0].owner?.login}', style: TypographyType.body),
            const SizedBox(
              height: 10,
            ),
            const CustomText(text: "Descrição", style: TypographyType.title),
            CustomText(
                text: '${repo[0].description}', style: TypographyType.body,
                textAlign: TextAlign.center,
                )
          ],
        ),
      )),
    );
  }
}
